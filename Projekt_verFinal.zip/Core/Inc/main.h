/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define MFX_IRQ_OUT_Pin GPIO_PIN_13
#define MFX_IRQ_OUT_GPIO_Port GPIOC
#define JOY_CENTER_Pin GPIO_PIN_0
#define JOY_CENTER_GPIO_Port GPIOA
#define JOY_LEFT_Pin GPIO_PIN_1
#define JOY_LEFT_GPIO_Port GPIOA
#define JOY_RIGHT_Pin GPIO_PIN_2
#define JOY_RIGHT_GPIO_Port GPIOA
#define JOY_UP_Pin GPIO_PIN_3
#define JOY_UP_GPIO_Port GPIOA
#define MFX_WAKEUP_Pin GPIO_PIN_4
#define MFX_WAKEUP_GPIO_Port GPIOA
#define JOY_DOWN_Pin GPIO_PIN_5
#define JOY_DOWN_GPIO_Port GPIOA
#define NIC_NIE_DAJE_Pin GPIO_PIN_6
#define NIC_NIE_DAJE_GPIO_Port GPIOA
#define cDP_Pin GPIO_PIN_7
#define cDP_GPIO_Port GPIOA
#define aG_Pin GPIO_PIN_4
#define aG_GPIO_Port GPIOC
#define cC_Pin GPIO_PIN_5
#define cC_GPIO_Port GPIOC
#define aA_Pin GPIO_PIN_0
#define aA_GPIO_Port GPIOB
#define cE_Pin GPIO_PIN_1
#define cE_GPIO_Port GPIOB
#define LD_R_Pin GPIO_PIN_2
#define LD_R_GPIO_Port GPIOB
#define LD_G_Pin GPIO_PIN_8
#define LD_G_GPIO_Port GPIOE
#define SERVO_Piwnica_Pin GPIO_PIN_11
#define SERVO_Piwnica_GPIO_Port GPIOE
#define SERVO_Ramie_Pin GPIO_PIN_13
#define SERVO_Ramie_GPIO_Port GPIOE
#define SERVO_Lokiec_Pin GPIO_PIN_14
#define SERVO_Lokiec_GPIO_Port GPIOE
#define MFX_I2C_SLC_Pin GPIO_PIN_10
#define MFX_I2C_SLC_GPIO_Port GPIOB
#define MFX_I2C_SDA_Pin GPIO_PIN_11
#define MFX_I2C_SDA_GPIO_Port GPIOB
#define aF_Pin GPIO_PIN_12
#define aF_GPIO_Port GPIOB
#define cD_Pin GPIO_PIN_13
#define cD_GPIO_Port GPIOB
#define aB_Pin GPIO_PIN_14
#define aB_GPIO_Port GPIOB
#define bDP_Pin GPIO_PIN_15
#define bDP_GPIO_Port GPIOB
#define bG_Pin GPIO_PIN_8
#define bG_GPIO_Port GPIOD
#define bC_Pin GPIO_PIN_9
#define bC_GPIO_Port GPIOD
#define bF_Pin GPIO_PIN_10
#define bF_GPIO_Port GPIOD
#define bD_Pin GPIO_PIN_11
#define bD_GPIO_Port GPIOD
#define bA_Pin GPIO_PIN_12
#define bA_GPIO_Port GPIOD
#define bE_Pin GPIO_PIN_13
#define bE_GPIO_Port GPIOD
#define bB_Pin GPIO_PIN_14
#define bB_GPIO_Port GPIOD
#define aDP_Pin GPIO_PIN_15
#define aDP_GPIO_Port GPIOD
#define cF_Pin GPIO_PIN_6
#define cF_GPIO_Port GPIOC
#define aC_Pin GPIO_PIN_7
#define aC_GPIO_Port GPIOC
#define cG_Pin GPIO_PIN_8
#define cG_GPIO_Port GPIOC
#define OTG_FS_PowerSwitchOn_Pin GPIO_PIN_9
#define OTG_FS_PowerSwitchOn_GPIO_Port GPIOC
#define cB_Pin GPIO_PIN_8
#define cB_GPIO_Port GPIOA
#define OTG_FS_DM_Pin GPIO_PIN_11
#define OTG_FS_DM_GPIO_Port GPIOA
#define OTG_FS_DP_Pin GPIO_PIN_12
#define OTG_FS_DP_GPIO_Port GPIOA
#define SWDIO_Pin GPIO_PIN_13
#define SWDIO_GPIO_Port GPIOA
#define SWCLK_Pin GPIO_PIN_14
#define SWCLK_GPIO_Port GPIOA
#define aD_Pin GPIO_PIN_15
#define aD_GPIO_Port GPIOA
#define OTG_FS_OverCurrent_Pin GPIO_PIN_10
#define OTG_FS_OverCurrent_GPIO_Port GPIOC
#define OTG_FS_VBUS_Pin GPIO_PIN_11
#define OTG_FS_VBUS_GPIO_Port GPIOC
#define EXT_RST_Pin GPIO_PIN_0
#define EXT_RST_GPIO_Port GPIOD
#define USART_TX_Pin GPIO_PIN_5
#define USART_TX_GPIO_Port GPIOD
#define USART_RX_Pin GPIO_PIN_6
#define USART_RX_GPIO_Port GPIOD
#define M3V3_REG_ON_Pin GPIO_PIN_3
#define M3V3_REG_ON_GPIO_Port GPIOB
#define aE_Pin GPIO_PIN_4
#define aE_GPIO_Port GPIOB
#define cA_Pin GPIO_PIN_5
#define cA_GPIO_Port GPIOB
#define SERVO_Chwytak_Pin GPIO_PIN_6
#define SERVO_Chwytak_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
