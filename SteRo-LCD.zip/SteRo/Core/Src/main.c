/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/

// Konfiguracja wyswietlacza
// Pierwsza litera - numer wyswietlacza
// Druga litera - nazwa segmentu
void aF(){ HAL_GPIO_WritePin(aF_GPIO_Port, aF_Pin, GPIO_PIN_RESET);}
void cD(){ HAL_GPIO_WritePin(cD_GPIO_Port, cD_Pin, GPIO_PIN_RESET);}
void aB(){ HAL_GPIO_WritePin(aB_GPIO_Port, aB_Pin, GPIO_PIN_RESET);}
void bDP(){ HAL_GPIO_WritePin(bDP_GPIO_Port, bDP_Pin, GPIO_PIN_RESET);}
void bG(){ HAL_GPIO_WritePin(bG_GPIO_Port, bG_Pin, GPIO_PIN_RESET);}
void bC(){ HAL_GPIO_WritePin(bC_GPIO_Port, bC_Pin, GPIO_PIN_RESET);}
void bF(){ HAL_GPIO_WritePin(bF_GPIO_Port, bF_Pin, GPIO_PIN_RESET);}
void bD(){ HAL_GPIO_WritePin(bD_GPIO_Port, bD_Pin, GPIO_PIN_RESET);}
void bA(){ HAL_GPIO_WritePin(bA_GPIO_Port, bA_Pin, GPIO_PIN_RESET);}
void bE(){ HAL_GPIO_WritePin(bE_GPIO_Port, bE_Pin, GPIO_PIN_RESET);}
void bB(){ HAL_GPIO_WritePin(bB_GPIO_Port, bB_Pin, GPIO_PIN_RESET);}
void aDP(){ HAL_GPIO_WritePin(aDP_GPIO_Port, aDP_Pin, GPIO_PIN_RESET);}
void cF(){ HAL_GPIO_WritePin(cF_GPIO_Port, cF_Pin, GPIO_PIN_RESET);}
void aC(){ HAL_GPIO_WritePin(aC_GPIO_Port, aC_Pin, GPIO_PIN_RESET);}
void cG(){ HAL_GPIO_WritePin(cG_GPIO_Port, cG_Pin, GPIO_PIN_RESET);}
void cB(){ HAL_GPIO_WritePin(cB_GPIO_Port, cB_Pin, GPIO_PIN_RESET);}
void cE(){ HAL_GPIO_WritePin(cE_GPIO_Port, cE_Pin, GPIO_PIN_RESET);}
void aA(){ HAL_GPIO_WritePin(aA_GPIO_Port, aA_Pin, GPIO_PIN_RESET);}
void cC(){ HAL_GPIO_WritePin(cC_GPIO_Port, cC_Pin, GPIO_PIN_RESET);}
void aG(){ HAL_GPIO_WritePin(aG_GPIO_Port, aG_Pin, GPIO_PIN_RESET);}
void cDP(){ HAL_GPIO_WritePin(cDP_GPIO_Port, cDP_Pin, GPIO_PIN_RESET);}
void aE(){ HAL_GPIO_WritePin(aE_GPIO_Port, aE_Pin, GPIO_PIN_RESET);}
void cA(){ HAL_GPIO_WritePin(cA_GPIO_Port, cA_Pin, GPIO_PIN_RESET);}
void aD(){ HAL_GPIO_WritePin(aD_GPIO_Port, aD_Pin, GPIO_PIN_RESET);}

  void resetLCD(){ // czyszczenie calego wyswietlacza
	  HAL_GPIO_WritePin(aA_GPIO_Port, aA_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(aB_GPIO_Port, aB_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(aC_GPIO_Port, aC_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(aD_GPIO_Port, aD_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(aE_GPIO_Port, aE_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(aF_GPIO_Port, aF_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(aG_GPIO_Port, aG_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(aDP_GPIO_Port, aDP_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bA_GPIO_Port, bA_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bB_GPIO_Port, bB_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bC_GPIO_Port, bC_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bD_GPIO_Port, bD_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bE_GPIO_Port, bE_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bF_GPIO_Port, bF_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bG_GPIO_Port, bG_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bDP_GPIO_Port, bDP_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cA_GPIO_Port, cA_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cB_GPIO_Port, cB_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cC_GPIO_Port, cC_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cD_GPIO_Port, cD_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cE_GPIO_Port, cE_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cF_GPIO_Port, cF_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cG_GPIO_Port, cG_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cDP_GPIO_Port, cDP_Pin, GPIO_PIN_SET);
  }
  void resetbc(){ // czyszczenie dwoch prawych segmentow (d kinematyki odwrotnej)
	  HAL_GPIO_WritePin(bA_GPIO_Port, bA_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bB_GPIO_Port, bB_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bC_GPIO_Port, bC_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bD_GPIO_Port, bD_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bE_GPIO_Port, bE_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bF_GPIO_Port, bF_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bG_GPIO_Port, bG_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(bDP_GPIO_Port, bDP_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cA_GPIO_Port, cA_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cB_GPIO_Port, cB_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cC_GPIO_Port, cC_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cD_GPIO_Port, cD_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cE_GPIO_Port, cE_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cF_GPIO_Port, cF_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cG_GPIO_Port, cG_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(cDP_GPIO_Port, cDP_Pin, GPIO_PIN_SET);
  }

void X(){ aB(); aC(); aE(); aG(); aF(); aDP();} // wspolzedna x
void Y(){ aB(); aC(); aG(); aF(); aDP();} // wspolzedna y
void S1(){ aA(); aF(); aG(); aC(); aD(); aDP(); cB(); cC();} // serwo 1
void S2(){ aA(); aF(); aG(); aC(); aD(); aDP(); cA(); cB(); cG(); cE(); cD();} // serwo 2
void S3(){ aA(); aF(); aG(); aC(); aD(); aDP(); cA(); cB(); cG(); cC(); cD();} // serwo 3
void S4(){ aA(); aF(); aG(); aC(); aD(); aDP(); cF(); cG(); cB(); cC();} // serwo 4

// Wyswietlanie konkretnych numerow

int numerLCD(int numer){
	switch(numer){
	case 0:  bA(); bB(); bC(); bD(); bE(); bF(); cA(); cB(); cC(); cD(); cE(); cF(); break;
	case 5:  cA(); cF(); cG(); cC(); cD(); break;
	case 10: bB(); bC(); cA(); cB(); cC(); cD(); cE(); cF(); break;
	case 15: bB(); bC(); cA(); cF(); cG(); cC(); cD(); break;
	case 20: bA(); bB(); bG(); bE(); bD(); cA(); cB(); cC(); cD(); cE(); cF(); break;
	case 25: bA(); bB(); bG(); bE(); bD(); cA(); cF(); cG(); cC(); cD(); break;
	case 30: bA(); bB(); bG(); bC(); bD(); cA(); cB(); cC(); cD(); cE(); cF(); break;
	case 35: bA(); bB(); bG(); bC(); bD(); cA(); cF(); cG(); cC(); cD(); break;
	case 40: bF(); bG(); bB(); bC(); cA(); cB(); cC(); cD(); cE(); cF(); break;
	case 45: bF(); bG(); bB(); bC(); cA(); cF(); cG(); cC(); cD(); break;
	case 50: bA(); bF(); bG(); bC(); bD(); cA(); cB(); cC(); cD(); cE(); cF(); break;
	case 55: bA(); bF(); bG(); bC(); bD(); cA(); cF(); cG(); cC(); cD(); break;
	case 60: bA(); bF(); bG(); bE(); bC(); bD(); cA(); cB(); cC(); cD(); cE(); cF(); break;
	case 65: bA(); bF(); bG(); bE(); bC(); bD(); cA(); cF(); cG(); cC(); cD(); break;
	case 70: bA(); bB(); bC(); cA(); cB(); cC(); cD(); cE(); cF(); break;
	case 75: bA(); bB(); bC(); cA(); cF(); cG(); cC(); cD(); break;
	case 80: bA(); bF(); bG(); bE(); bC(); bD(); bB(); cA(); cB(); cC(); cD(); cE(); cF(); break;
	case 85: bA(); bF(); bG(); bE(); bC(); bD(); bB(); cA(); cF(); cG(); cC(); cD(); break;
	case 90: bA(); bF(); bG(); bC(); bD(); bB(); cA(); cB(); cC(); cD(); cE(); cF(); break;
	case 95: bA(); bF(); bG(); bC(); bD(); bB(); cA(); cF(); cG(); cC(); cD(); break;
	}
}

void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

// 1 - SERVO_Chwytak (stopnie: 0-80) PB6
// 2 - SERVO_Piwnica (stopnie: 0-190) PE11
// 3 - SERVO_Ramie (stopnie: 30-180) PE13
// 4 - SERVO_Lokiec (stopnie: 30-130) PE14
float setServo(int servo_nr, int degree)
{
	float pwm_duty = 0;		// zakres 25-120 (0.5-2.4 ms)

	switch(servo_nr)
	{
	case 1:
		resetLCD();
		S1();
		pwm_duty = degree * 95 / 180 + 25;
		pwm_duty = 145 - pwm_duty;
		__HAL_TIM_SET_COMPARE(&htim4 , TIM_CHANNEL_1, pwm_duty);	// SERVO_Chwytak
	break;

	case 2:
		resetLCD();
		S2();
		pwm_duty = degree * 95 / 180 + 25;
		__HAL_TIM_SET_COMPARE(&htim1 , TIM_CHANNEL_2, pwm_duty);	// SERVO_Piwnica
	break;

	case 3:
		resetLCD();
		S3();
		pwm_duty = degree * 95 / 180 + 25;
		pwm_duty = 145 - pwm_duty;
		__HAL_TIM_SET_COMPARE(&htim1 , TIM_CHANNEL_3, pwm_duty);	// SERVO_Ramie
	break;

	case 4:
		resetLCD();
		S4();
		pwm_duty = degree * 95 / 135 + 25;
		pwm_duty = 145 - pwm_duty;
		__HAL_TIM_SET_COMPARE(&htim1 , TIM_CHANNEL_4, pwm_duty);	// SERVO_Lokiec
	break;

	default:
		// BLAD
		pwm_duty = 0;
	break;
	}

	return pwm_duty;
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	int numer=0; // pozwala na przedstawienie liczy na wyswietlaczu (swich)
	int kServoX=0; // pozwala na przechowanie wartosci kata dla serwa X (do kineatyki odwrotnej)
	int kServoY=0; // pozwala na przechowanie wartosci kata dla serwa Y (do kineatyki odwrotnej)
	int servo_nr = 1;
	int licznik = 0; //zmienna do wyswietlania przywitania na LCD
	float degree[5] = {0, 0, 90, 60, 45};	// pozycja w tablicy odpowiada servo_nr, stąd nadmiarowa pozycja zerowa

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C2_Init();
  MX_USART2_UART_Init();
  MX_TIM1_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */

  __HAL_TIM_SET_COMPARE(&htim1 , TIM_CHANNEL_2, 0);
  __HAL_TIM_SET_COMPARE(&htim1 , TIM_CHANNEL_3, 0);
  __HAL_TIM_SET_COMPARE(&htim1 , TIM_CHANNEL_4, 0);
  __HAL_TIM_SET_COMPARE(&htim4 , TIM_CHANNEL_1, 0);
  HAL_TIM_PWM_Start(&htim1 , TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim1 , TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim1 , TIM_CHANNEL_4);
  HAL_TIM_PWM_Start(&htim4 , TIM_CHANNEL_1);

  // inicjowanie pozycji przegubow
  setServo(1, degree[1]);
  setServo(2, degree[2]);
  setServo(3, degree[3]);
  setServo(4, degree[4]);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {
	  if(licznik==0){ // wyswietlanie przywitania
		resetLCD();
		aA(); aB(); aF(); aG(); bD(), cA(); cB(); cF(); cG();
		HAL_Delay(3000);
		resetLCD();
		S1();
		HAL_Delay(3000);
		licznik=1;
	  }



	  if(HAL_GPIO_ReadPin(JOY_UP_GPIO_Port, JOY_UP_Pin) ) // zwiekszanie przyciskiem w gore
	  {
		  HAL_GetTick();	// debouncing

		  degree[servo_nr] += 5;
		  setServo(servo_nr, degree[servo_nr]);

		  while(HAL_GPIO_ReadPin(JOY_UP_GPIO_Port, JOY_UP_Pin) )	// czekaj na puszczenie przycisku
		  {
			  HAL_Delay(10);
		  }

		  HAL_GetTick();	// debouncing
	  }

	  if(HAL_GPIO_ReadPin(JOY_DOWN_GPIO_Port, JOY_DOWN_Pin) ) // zmniejszanie przyciskiem w dol
	  {
		  HAL_GetTick();

		  degree[servo_nr] -= 5;
		  setServo(servo_nr, degree[servo_nr]);

		  while(HAL_GPIO_ReadPin(JOY_DOWN_GPIO_Port, JOY_DOWN_Pin) )	// czekaj na puszczenie przycisku
		  {
			  HAL_Delay(10);
		  }

		  HAL_GetTick();	// debouncing
	  }


	  if(HAL_GPIO_ReadPin(JOY_RIGHT_GPIO_Port, JOY_RIGHT_Pin) ) // zmiana sewa przyciskiem w prawo
	  {
		  HAL_GetTick();
		  if(servo_nr<=4){
			  	  ++servo_nr;
			  	  setServo(servo_nr, degree[servo_nr]);
		  }

		  if(servo_nr==5) { // przejscie z serwa 4 na serwo 1
			  resetLCD();
			  S1();
			  servo_nr=1;
		  }

		  while(HAL_GPIO_ReadPin(JOY_RIGHT_GPIO_Port, JOY_RIGHT_Pin) )	// czekaj na puszczenie przycisku
		  {
			  HAL_Delay(10);
		  }
		  HAL_GetTick();	// debouncing
	  }



	  /////////////////////////////////// Kinematyka odwrotna
	  int wyjscie=0; // zmienna sluzaca do wychodzenia z petli w kinematyce odwrotnej (wychodzenie z kinematyki odwrotnej)
	  if(HAL_GPIO_ReadPin(JOY_LEFT_GPIO_Port, JOY_LEFT_Pin) ) // pobieranie wspolzednej x
	  {
	      HAL_GetTick();
	      resetLCD(); // czyszczenie wyswietlacza i pokazywanie ze czekamy na wartosc X
	      X();
	      while(HAL_GPIO_ReadPin(JOY_LEFT_GPIO_Port, JOY_LEFT_Pin) )	// czekaj na puszczenie przycisku
	      {
	          HAL_Delay(10);
	      }
	      HAL_GetTick();	// debouncing


	      while(wyjscie==0)  // jezeli wyjscie jest inne niz 0 to wychodze z kinematyki odwrotnej (pela 1)
	      {

	          if(HAL_GPIO_ReadPin(JOY_UP_GPIO_Port, JOY_UP_Pin) ) // zwiekszanie kata
	          {
	              HAL_GetTick();	// debouncing

	              if(kServoX<=90)  // zeby nie wyjsc poza zakres 0-95 stopni
	              {
	                  kServoX = kServoX + 5; // dodawanie co 5 pozycji na jakie ma sie ustawic serwo
	                  numer=kServoX; // pozwala na przedstawienie liczby na wyswietlaczu
	                  resetbc(); // reset liczb z dwoch prawych segmentow
	                  numerLCD(numer); // switch z numerami
	              }

	              while(HAL_GPIO_ReadPin(JOY_UP_GPIO_Port, JOY_UP_Pin) )	// czekaj na puszczenie przycisku
	              {
	                  HAL_Delay(10);
	              }

	              HAL_GetTick();	// debouncing
	          }

	          if(HAL_GPIO_ReadPin(JOY_DOWN_GPIO_Port, JOY_DOWN_Pin) ) // zmniejszanie kata
	          {
	              HAL_GetTick();	// debouncing

	              if(kServoX>=5)
	              {
	                  kServoX = kServoX - 5; // dodawanie co 5 pozycji na jakie ma sie ustawic serwo
	                  numer=kServoX; // pozwala na przedstawienie liczby na wyswietlaczu
	                  resetbc(); // reset liczb z dwoch prawych segmentow
	                  numerLCD(numer); // switch z numerami
	              }

	              while(HAL_GPIO_ReadPin(JOY_DOWN_GPIO_Port, JOY_DOWN_Pin) )	// czekaj na puszczenie przycisku
	              {
	                  HAL_Delay(10);
	              }

	              HAL_GetTick();	// debouncing
	          }

	          if(HAL_GPIO_ReadPin(JOY_RIGHT_GPIO_Port, JOY_RIGHT_Pin) ) // wychodzenie z kinematyki odwrotnej
	          {
	              HAL_GetTick();
	              wyjscie = 1;
	              while(HAL_GPIO_ReadPin(JOY_RIGHT_GPIO_Port, JOY_RIGHT_Pin) )	// czekaj na puszczenie przycisku
	              {
	                  HAL_Delay(10);
	              }
	              HAL_GetTick();	// debouncing
	          }


	          ////////////////////// pobieranie wspolzednej y /////////////////////// (petla 2)

	          if(HAL_GPIO_ReadPin(JOY_LEFT_GPIO_Port, JOY_LEFT_Pin))  // pobieranie wspolzednej y
	          {
	              resetLCD();
	              Y();

	              while(HAL_GPIO_ReadPin(JOY_LEFT_GPIO_Port, JOY_LEFT_Pin) )	// czekaj na puszczenie przycisku
	              {
	                  HAL_Delay(10);
	              }
	              HAL_GetTick();	// debouncing



	              while(wyjscie == 0) // jezeli wyjscie jest inne niz 0 to wychodze z kinematyki odwrotnej
	              {


	                  if(HAL_GPIO_ReadPin(JOY_UP_GPIO_Port, JOY_UP_Pin) ) // zwiekszanie kata
	                  {
	                      HAL_GetTick();	// debouncing

	                      if(kServoY<=90)  // zeby nie wyjsc poza zakres 0-95 stopni
	                      {
	                          kServoY = kServoY + 5; // dodawanie co 5 pozycji na jakie ma sie ustawic serwo
	                          numer=kServoY; // pozwala na przedstawienie liczby na wyswietlaczu
	                          resetbc(); // reset liczb z dwoch prawych segmentow
	                          numerLCD(numer); // switch z numerami
	                      }

	                      while(HAL_GPIO_ReadPin(JOY_UP_GPIO_Port, JOY_UP_Pin) )	// czekaj na puszczenie przycisku
	                      {
	                          HAL_Delay(10);
	                      }

	                      HAL_GetTick();	// debouncing
	                  }

	                  if(HAL_GPIO_ReadPin(JOY_DOWN_GPIO_Port, JOY_DOWN_Pin) ) // zmniejszanie kata
	                  {
	                      HAL_GetTick();	// debouncing

	                      if(kServoY>=5)
	                      {
	                          kServoY = kServoY - 5; // dodawanie co 5 pozycji na jakie ma sie ustawic serwo
	                          numer=kServoY; // pozwala na przedstawienie liczby na wyswietlaczu
	                          resetbc(); // reset liczb z dwoch prawych segmentow
	                          numerLCD(numer); // switch z numerami
	                      }

	                      while(HAL_GPIO_ReadPin(JOY_DOWN_GPIO_Port, JOY_DOWN_Pin) )	// czekaj na puszczenie przycisku
	                      {
	                          HAL_Delay(10);
	                      }

	                      HAL_GetTick();	// debouncing
	                  }

	                  if(HAL_GPIO_ReadPin(JOY_RIGHT_GPIO_Port, JOY_RIGHT_Pin) ) // wychodzenie z kinematyki odwrotnej
	                  {
	                      HAL_GetTick();
	                      wyjscie = 1;
	                      while(HAL_GPIO_ReadPin(JOY_RIGHT_GPIO_Port, JOY_RIGHT_Pin) )	// czekaj na puszczenie przycisku
	                      {
	                          HAL_Delay(10);
	                      }
	                      HAL_GetTick();	// debouncing
	                  }




	                  ///////////////////// Ustawianie robota z zadanych wartosci (petla 3)
	                  if( HAL_GPIO_ReadPin(JOY_LEFT_GPIO_Port, JOY_LEFT_Pin))  // czas do ustawiania robota
	                  {
	                      resetLCD();
	                      aG();
	                      bG();
	                      cG();


	                      while(HAL_GPIO_ReadPin(JOY_LEFT_GPIO_Port, JOY_LEFT_Pin) )	// czekaj na puszczenie przycisku
	                      {
	                          HAL_Delay(10);
	                      }

	                      HAL_GetTick();	// debouncing

	                      while (wyjscie == 0)
	                      {

	                          if(HAL_GPIO_ReadPin(JOY_RIGHT_GPIO_Port, JOY_RIGHT_Pin) ) // wychodzenie z kinematyki odwrotnej
	                          {
	                              HAL_GetTick();
	                              wyjscie = 1;
	                              while(HAL_GPIO_ReadPin(JOY_RIGHT_GPIO_Port, JOY_RIGHT_Pin) )	// czekaj na puszczenie przycisku
	                              {
	                                  HAL_Delay(10);
	                              }
	                              HAL_GetTick();	// debouncing
	                          }
	                      }
	                  }

	              }
	          }
	      }
	  }






	  //////////////////////////////////////////////////////////////////////////////////////////




	  if(degree[servo_nr] < 90 && degree[servo_nr] > 0)
	  {
		  HAL_GPIO_WritePin(LD_G_GPIO_Port, LD_G_Pin, GPIO_PIN_SET);
	  }
	  else
	  {
		  HAL_GPIO_WritePin(LD_G_GPIO_Port, LD_G_Pin, GPIO_PIN_RESET);
	  }

	  if(degree[servo_nr] > 180)
	  {
		  HAL_GPIO_WritePin(LD_R_GPIO_Port, LD_R_Pin, GPIO_PIN_SET);
	  }
	  else
	  {
		  HAL_GPIO_WritePin(LD_R_GPIO_Port, LD_R_Pin, GPIO_PIN_RESET);
	  }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_I2C2;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c2ClockSelection = RCC_I2C2CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the main internal regulator output voltage 
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
